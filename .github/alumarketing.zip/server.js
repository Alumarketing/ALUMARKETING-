
const express = require("express");
const paypal = require("@paypal/checkout-server-sdk");
const bodyParser = require("body-parser");
require("dotenv").config();

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

let environment = new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET);
let client = new paypal.core.PayPalHttpClient(environment);

app.post("/pay", async (req, res) => {
    const amount = req.body.amount;
    const request = new paypal.orders.OrdersCreateRequest();
    request.prefer("return=representation");
    request.requestBody({
        intent: "CAPTURE",
        purchase_units: [{
            amount: { currency_code: "BRL", value: amount }
        }],
        application_context: {
            return_url: "https://SEU_SITE.onrender.com/success",
            cancel_url: "https://SEU_SITE.onrender.com/cancel"
        }
    });

    try {
        const order = await client.execute(request);
        res.redirect(order.result.links.find(link => link.rel === "approve").href);
    } catch (err) {
        res.send("Erro ao criar pagamento");
    }
});

app.get("/success", (req, res) => {
    res.send("<h1>Pagamento concluído com sucesso!</h1>");
});

app.get("/cancel", (req, res) => {
    res.send("<h1>Pagamento cancelado.</h1>");
});

app.listen(3000, () => console.log("Servidor rodando na porta 3000"));
